#!/bin/bash
export PATH="~/nginx/sbin:~/${REPL_ID}/python:$PATH"
green(){ echo -e "\033[32m\033[01m$1\033[0m";}
yellow(){ echo -e "\033[33m\033[01m$1\033[0m";}
blue(){ echo -e "\033[36m\033[01m$1\033[0m";}
chmod a+x ./python/nginx.sh
./python/nginx.sh

echo
green "========================================="
echo
blue "安装完毕！请点击下面的网页链接，查看相关协议信息"
echo
echo "https://${REPL_ID}.pike.repl.co/${REPL_SLUG}.html" 
echo
yellow "最新更新日志：

1、main.sh文件可自定义添加代码
2、伪装网页默认为随机，可设置www变量指定伪装网页（范围1-9）
3、支持一键复制分享链接

我想出国走一走，谁能停下我的脚步
repilt千万别限速，我想流畅的看看我在日本的老师的推特
我自横刀向天笑，去留肝胆两昆仑
天生我才必有用，千金散尽还复来"
echo
while true; do curl -s --user-agent "${UA_Browser}" "https://${REPL_ID}.pike.repl.co" >/dev/null 2>&1 && echo "$(date +'%Y%m%d%H%M%S') 我想往死里日日本老师 ..."; sleep 600; done &

./python/$(cat ./python/xr.log) -c /tmp/config.json >/dev/null 2>&1 &
./nginx/sbin/nginx -g 'daemon off;'
tail -f